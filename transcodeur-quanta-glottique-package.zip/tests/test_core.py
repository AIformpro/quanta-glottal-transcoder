from zqgt.core import QuantaGlotticTranscoder
def test_roundtrip():
    t = QuantaGlotticTranscoder()
    x = t.encode("ok")
    assert t.decode(x) == "ok"
