from zqgt.core import *
print("OK")
