class QuantaGlotticTranscoder:
    def encode(self, text):
        return text.encode("utf-8")
    def decode(self, data):
        return data.decode("utf-8")
